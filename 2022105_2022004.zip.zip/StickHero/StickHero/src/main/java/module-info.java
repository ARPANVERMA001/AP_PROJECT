module stickhero.stickhero {
    requires javafx.controls;
    requires javafx.fxml;
    requires junit;
    requires javafx.media;


    opens stickhero.stickhero to javafx.fxml;
    exports stickhero.stickhero;
}