package stickhero.stickhero;
import org.junit.*;


import static org.junit.Assert.*;

public class GamePlayControllerTest {
    @Test
    public void test_stick_height() {
        System.out.println("!@#$!#!#$%@!%@!%#!%#@!%#@!%#@!$^@!%^$#@!^$@#!^$#@!");
        System.out.println(GamePlayController.get_stick().height);
        Assert.assertNotEquals(GamePlayController.get_stick().height, 0);
    }
    @Test
    public void test_lives(){
        Assert.assertTrue(GamePlayController.lives>=0);
    }
    @Test
    public void test_hero_max(){
        Assert.assertNotEquals(GamePlayController.get_hero_max(),125.0);
    }
}