package stickhero.stickhero;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Objects;
import static javafx.application.ConditionalFeature.FXML;

public class Main extends Application {
    private static Stage stage = null;
    @Override
    public void start(Stage stage) throws IOException {
        music();
        this.stage = stage;
        Parent root  = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("StartMenu.fxml")));
        Scene scene = new Scene(root,800,600);
        stage.setTitle("StickHero!");
        stage.setScene(scene);
        stage.show();
    }
    public static Stage get_stage(){
        return stage;
    }

    MediaPlayer mediaPlayer;
    public void music(){
        String s = "D:\\Codes\\StickHero\\StickHero\\src\\main\\resources\\stickhero\\stickhero\\play_music.mp3";
        Media h = new Media(new File(s).toURI().toString());
        mediaPlayer = new MediaPlayer(h);
        mediaPlayer.play();
    }

    public static void main(String[] args) {
        launch(args);
    }
}