package stickhero.stickhero;

public class Lives implements Collectable{
    public void spawn(){

    }
    public void despawn(){

    }
}
