package stickhero.stickhero;

import javafx.scene.image.ImageView;

public abstract class HeroDecorator extends Hero {
    public HeroDecorator(Hero hero){
        super(hero.hero);
    }
    public abstract void change_character_outfit();
}