package stickhero.stickhero;

public class ContinueController {
    private int lives;
    private int cherries;

    public void continue_to_Game(int lives, int cherries){
        this.lives = lives;
        this.cherries = cherries;


    }
}
