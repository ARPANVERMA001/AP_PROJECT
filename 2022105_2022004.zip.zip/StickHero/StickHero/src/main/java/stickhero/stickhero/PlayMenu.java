package stickhero.stickhero;

import javafx.scene.input.MouseEvent;

public class PlayMenu {
    public void background_start(MouseEvent mouseEvent) {
    }
}
