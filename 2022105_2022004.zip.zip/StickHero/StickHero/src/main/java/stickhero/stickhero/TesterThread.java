package stickhero.stickhero;

import javafx.application.Platform;

public class TesterThread extends Thread{
//    private double timer;
    private boolean running;

    TesterThread(){
        this.running=true;
    }

    public void stop_timer(){
        running = false;
    }
    public void start_timer(){
        running=true;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(10000); // Sleep for 1 second (1000 milliseconds)
                if(running) {
                    GamePlayControllerTestRunner.main();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}