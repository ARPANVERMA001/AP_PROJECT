package stickhero.stickhero;

import javafx.scene.image.ImageView;

public class ImageResource {
    public ImageView image;
    ImageResource(ImageView image){
        this.image = image;
    }
}