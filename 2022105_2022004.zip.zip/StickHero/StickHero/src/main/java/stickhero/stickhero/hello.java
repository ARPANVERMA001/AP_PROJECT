//package com.example.apendsempractice;
//import org.junit.*;
//
//import java.util.ArrayList;
//
//import static org.junit.Assert.*;
//public class TestArray {
//
//    @BeforeClass
//    public static void init() throws LowException {
//        Array1.initialise_array();
//        System.out.println("YEAHH!!");
//    }
//
//    @Test
//    public void testarray1(){
//        int index=BinarySearch.binary_search(Array1.get_array(),0, 10, 0);
//        assertNotEquals(index, -1);
//    }
//    @Test
//    public void testarray2(){
//        int index=BinarySearch.binary_search(Array1.get_array(),0, 10, 10);
//        assertNotEquals(index, -1);
//    }
//    @Test
//    public void testarray3(){
//        int index=BinarySearch.binary_search(Array1.get_array(),0, 10, -1);
//        assertNotEquals(index, -1);
//    }
//}