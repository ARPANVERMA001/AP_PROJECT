//package stickhero.stickhero;
//
//import java.awt.event.KeyEvent;
//import java.awt.event.KeyListener;
//import javax.swing.JFrame;
//
//private class MyKeyListener implements KeyListener {
//    @Override
//    public void keyTyped(KeyEvent e) {
//        // Not used in this example
//    }
//
//    @Override
//    public void keyPressed(KeyEvent e) {
//        int keyCode = e.getKeyCode();
//        if (keyCode == KeyEvent.VK_Y) {
//            System.out.println("Y pressed");
//        } else if (keyCode == KeyEvent.VK_N) {
//            System.out.println("N pressed");
//        }
//    }
//
//    @Override
//    public void keyReleased(KeyEvent e) {
//        // Not used in this example
//    }
//}
//
//    public static void main(String[] args) {
//        new KeyPressExample();
//    }
