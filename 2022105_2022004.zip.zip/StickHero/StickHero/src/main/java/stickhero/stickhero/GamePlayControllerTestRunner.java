package stickhero.stickhero;

import org.junit.*;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
public class GamePlayControllerTestRunner {
    public static void main() {
        Result result = JUnitCore.runClasses(GamePlayControllerTest.class);
        for (Failure failure : result.getFailures()) {
            System.out.println(failure.toString());
        }
        System.out.println(result.wasSuccessful());
    }
}