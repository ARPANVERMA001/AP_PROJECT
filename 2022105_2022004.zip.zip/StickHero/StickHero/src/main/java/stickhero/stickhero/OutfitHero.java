package stickhero.stickhero;

import javafx.scene.image.Image;

import java.util.Objects;
import java.util.Random;
public class OutfitHero extends HeroDecorator{
    public OutfitHero(Hero hero){
        super(hero);
    }
    @Override
    public void change_character_outfit(){
//        System.out.println("Inside change_character_outfit!!!!");
        if(GamePlayController.cherry_bonus%3==0){
//            System.out.println("Inside IFFFF     Inside change_character_outfit!!!!");
            Random random = new Random();
            int randint= random.nextInt(3);
            if(randint==0){
//                System.out.println("should -0");
                String image1="file:///D:\\Codes\\StickHero\\StickHero\\src\\main\\resources\\stickhero\\stickhero\\Images\\avatar2.png";
                GamePlayController.get_hero().hero.setImage(new Image(image1));
            }
            else if(randint==1){
//                System.out.println("should -1");
                String image1="file:///D:\\Codes\\StickHero\\StickHero\\src\\main\\resources\\stickhero\\stickhero\\Images\\avatar3.png";

                GamePlayController.get_hero().hero.setImage(new Image(image1));
            }
            else if(randint==2){
//                System.out.println("should -2");
                String image1="file:///D:\\Codes\\StickHero\\StickHero\\src\\main\\resources\\stickhero\\stickhero\\Images\\stickHero.png";
                GamePlayController.get_hero().hero.setImage(new Image(image1));
            }
            else{
//                System.out.println("shit hap[penionuhsdfhg");
            }
        }
    }
}