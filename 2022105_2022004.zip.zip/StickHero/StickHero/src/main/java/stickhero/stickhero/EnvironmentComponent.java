package stickhero.stickhero;

public interface EnvironmentComponent {
    public void spawn();
}
