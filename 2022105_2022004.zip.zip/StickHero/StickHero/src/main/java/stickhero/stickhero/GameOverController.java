package stickhero.stickhero;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class GameOverController {
    private Stage stage;
    private Scene scene;
    private Parent root;


    public void game_over_display(int lives, int score, int cherries){

    }
}