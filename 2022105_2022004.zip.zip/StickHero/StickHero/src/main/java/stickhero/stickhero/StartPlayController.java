package stickhero.stickhero;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;
import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;
public class StartPlayController implements Initializable {

    public int score, lives, cherries;
    private static Stage stage;
    private static Scene scene;
    private Save savedProgress;
    //    private Parent root;
    @FXML
    private ImageView saved_gameimg;

    @FXML
    private ImageView start_gameimg;

    @FXML
    private Label game_over_score;

    private static Labels game_over_score_;
    private static BackgroundImage start_gameimg_;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
//        System.out.println("hola!!!");
        start_gameimg_ = new BackgroundImage(saved_gameimg);
        game_over_score_ = new Labels(game_over_score);
    }

    public static Labels get_game_over_score_() {
        return game_over_score_;
    }

    public static BackgroundImage get_start_gameimg() {
        return start_gameimg_;
    }

    @FXML
    void select_saved_game() throws IOException {
        Stage stage = Main.get_stage();

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("GamePlay.fxml")));
        Scene scene = new Scene(root, 800, 600);
        stage.setTitle("StickHero!");
        stage.setScene(scene);

        GamePlayController.deserialize();
        savedProgress = GamePlayController.load_game();
//
//            background_move = 0;
        Background.underShoot = false;
        Background.overShoot = false;
        Background.check_cherry = 0;
        Background.cherry_current_updown = 1;
        GamePlayController.lives = savedProgress.getLives() + 1;
        GamePlayController.score = savedProgress.getScore();
        GamePlayController.cherry_bonus = savedProgress.getCherries();
        Background.stop_all = 0;
        stage.show();
    }

    @FXML
    void start_game() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("GamePlay.fxml")));

        scene = new Scene(root, 800, 600);
        stage = (Stage) ((Node) start_gameimg).getScene().getWindow();

//        stage.setWidth(800);
//        stage.setHeight(600);
//        stage.setResizable(false);
        stage.setScene(scene);

        stage.show();
    }
}