//package stickhero.stickhero;
//
//import junit.runner.*;
//import org.junit.runner.JUnitCore;
//import org.junit.runner.Result;
//import org.junit.runner.notification.Failure;
//
//public class Test {
//    public static void main(String[] args) {
//        Result result = JU
//    }
//}
