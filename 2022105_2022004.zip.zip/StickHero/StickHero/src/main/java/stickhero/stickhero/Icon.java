package stickhero.stickhero;
import javafx.scene.image.ImageView;

public class Icon {
    private ImageView icon_image;
    private static Icon instance;

    private Icon(ImageView icon_image) {
        this.icon_image = icon_image;
    }

    public static Icon getInstance(ImageView iconImage) {
        if (instance == null) {
            instance = new Icon(iconImage);
        }
        return instance;
    }

    public ImageView getIconImage() {
        return icon_image;
    }
}