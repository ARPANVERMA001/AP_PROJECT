package stickhero.stickhero;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Objects;
import java.util.Random;

import static java.lang.Thread.sleep;

public class Background {
    private static Stage stage;
    private static ImageView platform1;
    private static ImageView platform2;
    private static ImageView cherry_image;
    private static Rectangle stick;
    private static ImageView hero;
    private static Double hero_maxX;
    private static Timeline platform1timeline;
    private static Timeline platform2timeline;
    private static Timeline stick_shifttimeline;
    private static Timeline new_platformtimeline;
    private static Timeline cherrytimeline;
    private static Timeline new_sticktimeline;
    private static Timeline fall_charactertimeline;
    private static Timeline rotate_sticktimeline;

    public static boolean overShoot = false;
    public static boolean underShoot = false;
    private static boolean isValidPlacement = false;

    private static double pivotX;
    private static double pivotY;
    private static int stickLim;

    public static int stop_all;  // 1 if need to stop all, 0 otherwise
    private static final double speed=3.0;

    public static int check_cherry=0; //flag if cherry is collected or not!!  1 if cherry is collected, 0 otherwise!
    public static int cherry_current_updown=1; //1 if cherry is above stick level, 0 if cherry is below stick level!
    public static int flag_rotate_count=0;

    public Background(){

    }
    public static Timeline get_fall_timeline(){
        return fall_charactertimeline;
    }
    static void platform1_shift(){
        platform1.setTranslateX(platform1.getTranslateX() - speed);
        double platform1_maxX = platform1.getBoundsInParent().getMaxX();
//        System.out.println(platform1_maxX);
        if(platform1_maxX<=0){
//            System.out.println("Platform-1 has been stopped!!");
            platform1timeline.stop();
            Image platform2Image = platform2.getImage();
//
            platform1.setImage(platform2Image);
//            platform1.setScaleX(platform2.getScaleX());
//            stick = new
        }
    }

    static void platform2_shift(){
        if(stop_all==1){
            platform2timeline.stop();
        }
        collided_with_platform();
        platform2.setTranslateX(platform2.getTranslateX() - speed);
        double platform2_maxX = platform2.getBoundsInParent().getMaxX();
        if(check_cherry==0){
            int temp= GamePlayController.cherry_bonus;
            GamePlayController.checkCollision();
            if(temp<GamePlayController.cherry_bonus){
                check_cherry=1;                         //We have collected the cherry, Will set the check_cherry to 1 when the new platform has finished spawning!
            }
        }

        if(hero.getBoundsInParent().getMaxX()>=platform2.getBoundsInParent().getMinX()){
            GamePlayController.obstructing_flip = 1;
        }

//        System.out.println("999999999999999999999999999999");
//        System.out.println(GamePlayController.cherry_bonus);
        if(Math.floor(cherry_image.getBoundsInParent().getMaxX())<=0){
            cherrytimeline.stop();
        }
//        System.out.println(platform2_maxX);
        if(Math.floor(platform2_maxX)<=hero_maxX && !overShoot){
//            System.out.println("Platform2 has been stopped!!");
            platform2timeline.stop();
//            cherrytimeline.stop();
            stick_shifttimeline.stop();
            platform1.setTranslateX(platform1.getTranslateX()+hero_maxX);
            stick.setTranslateX(stick.getTranslateX()+hero_maxX);
            create_newplatform();
        }
    }

    static void cherry_shift(){
        cherry_image.setTranslateX(cherry_image.getTranslateX() - speed);
    }

    static void rotate_stick() throws IOException, InterruptedException {
        if(flag_rotate_count==90){
            rotate_sticktimeline.stop();
            if(underShoot){
                GamePlayController.get_game_over_text().image.setOpacity(1.0);
                GamePlayController.go_to_start();
            }
            GamePlayController.background_move=1;
            //Call the change background Code here!
            flag_rotate_count=0;
//            System.out.println("__________________________________Background shifting called!!__________________________________");
            return;
        }
        flag_rotate_count+=1;
//        System.out.println(flag_rotate_count);
//        isStickRotated = true;
        double pivotX = stick.getX() + stick.getWidth() / 2.0; // X-coordinate of the center of the stick
        double pivotY = stick.getY() + stick.getHeight();      // Y-coordinate at the bottom of the stick

        Rotate rotation = new Rotate(1, pivotX, pivotY);
//        Timeline t=new Timeline(new KeyFrame(Duration.))
        stick.getTransforms().add(rotation);
    }

    static void stick_shift() throws IOException, InterruptedException {
        if (underShoot){
//            System.out.println("inside undershoot condition!!!");

//            System.out.println("Inside stck_shift");
            if(stick.getBoundsInParent().getMaxX()<=hero_maxX){
//                System.out.println("inside if ");

                stick_shifttimeline.stop();
                platform1timeline.stop();
                platform2timeline.stop();
                cherrytimeline.stop();
                fall_charactertimeline.play();
                rotate_sticktimeline.play();
                stop_all=1;
                GamePlayController.get_timer().stop_timer();
//                GamePlayController.
                if(GamePlayController.lives > 0){
                    GamePlayController.get_respawn_text().image.setOpacity(1.0);
                    GamePlayController.get_yes_button().image.setOpacity(1.0);
                    GamePlayController.get_no_button().image.setOpacity(1.0);
                }
                else{
                    GamePlayController.get_game_over_text().image.setOpacity(1.0);
//                    if(stop_all == 1) {
//                        GamePlayController.go_to_start();
//                    }
//                    GamePlayController.go_to_start();
                }
//                StartPlayController.go_to_game_over(GamePlayController.get_lives(), GamePlayController.get_cherry_bonus(), GamePlayController.get_score());

            }
        }
        if (overShoot){
//            System.out.println("inside overshoot condition!!");
            if(stick.getBoundsInParent().getMaxX()<=hero_maxX+5){
//                System.out.println("inside if");
                stick_shifttimeline.stop();
                platform1timeline.stop();
                platform2timeline.stop();
                cherrytimeline.stop();
//                GamePlayController.get_game_over_text().image.setOpacity(1.0);
                fall_charactertimeline.play();
                stop_all=1;
                GamePlayController.get_timer().stop_timer();
                if(GamePlayController.lives > 0){
                    GamePlayController.get_yes_button().image.setOpacity(1.0);
                    GamePlayController.get_no_button().image.setOpacity(1.0);
                    GamePlayController.get_respawn_text().image.setOpacity(1.0);
//                    GamePlayController.respawn_decision();
                }
                else{
                    GamePlayController.get_game_over_text().image.setOpacity(1.0);
//                    if(stop_all == 1) {
//                         GamePlayController.go_to_start();
//                    }
                }
            }
        }
        stick.setTranslateX(stick.getTranslateX() - speed);
    }

    static void create_newplatform(){
        GamePlayController.score++;
        GamePlayController.get_score_label().label.setText(": "+GamePlayController.score);
        int platformpositionX= new Random().nextInt((650-350)+1)+350;
//        platform2
//        System.out.println(platform2.getTranslateY());
        platform2.setTranslateY(platform2.getTranslateY()+405);
        platform2.setTranslateX(platform2.getTranslateX()+platformpositionX);
//        System.out.println("Platform2 RandomXXX after set!:");
//        System.out.println(platform2.getX());
        double platformScaleX = 0.5 + new Random().nextDouble() * (1.25 - 0.5);
        platform2.setScaleX(platformScaleX);
        bring_back_stick();
//        new_sticktimeline.play();
        new_platformtimeline.play();
        //A delay of 2 seconds and then make the cherry come on the game screen! Make it visible


        //BRINGING CHERRY BACK!!!!!
        int cherryX= (int) (new Random().nextInt((int) ((platform2.getBoundsInParent().getMinX() - platform1.getBoundsInParent().getMaxX())+1))+platform1.getBoundsInParent().getMaxX());
        int up_down= new Random().nextInt((1 - 0) + 1);             //1-> above stick level, 0-> below stick level
        cherry_image.setOpacity(1);
        cherry_image.setTranslateX(cherry_image.getTranslateX()+cherryX);
        if(up_down==0){//Below stick level!
            if(cherry_current_updown==1){
                cherry_image.setTranslateY(cherry_image.getTranslateY()+50);
            }
            else if(cherry_current_updown==0){
                //Already Below stick level, do nothing!!
//                System.out.println("Already Below stick level, do nothing!!");
            }
            cherry_current_updown=0;
        }
        else if (up_down==1){//Above stick level!
            if(cherry_current_updown==1){
                //Already Above stick level, do nothing!!
//                System.out.println("Already Above stick level, do nothing!!");
            }
            else if(cherry_current_updown==0){
                cherry_image.setTranslateY(cherry_image.getTranslateY()-50);
            }
            cherry_current_updown=1;
        }
        else{
//            System.out.println("up_down value is wrong!!!!");
        }
    }

    static void collided_with_platform(){
        if(hero.getBoundsInParent().intersects(platform2.getBoundsInParent())) {
            fall_charactertimeline.play();
            platform2timeline.stop();
        }
    }

    static void bring_back_stick(){
        stick.setHeight(GamePlayController.get_stick_initial_height());
        pivotX = stick.getX() + stick.getWidth() / 2.0; // X-coordinate of the center of the stick
        pivotY = stick.getY() + stick.getHeight();      // Y-coordinate at the bottom of the stick
        Rotate rotation = new Rotate(270, pivotX, pivotY);
        stick.getTransforms().add(rotation);
        new_sticktimeline.play();
    }

    static void emerge_newplatform(){
        platform2.setTranslateY(platform2.getTranslateY()-3);
//        System.out.println(platform2.getTranslateY());
        if(platform2.getTranslateY()==0){
            new_platformtimeline.stop();
            GamePlayController.background_move=0;
            GamePlayController.obstructing_flip=0;
            check_cherry=0;
        }
    }

    static void bringing_stick(){
//        System.out.println("shittinnn");
        if(Math.floor(stick.getBoundsInParent().getMinX())>125){
            stick.setTranslateX(stick.getTranslateX() - 1);
//            System.out.println("get_translateX:");
//            System.out.println(stick.getBoundsInParent().getMinX());
        } else {
            stick.setTranslateX(stick.getTranslateX() + 1);
//            System.out.println("get_translateX:");
//            System.out.println(stick.getBoundsInParent().getMinX());
        }

        if (Math.floor(stick.getBoundsInParent().getMinX()) == 125) {
            new_sticktimeline.stop();
        }
    }
    static void falling_character() throws IOException, InterruptedException {
        hero.setTranslateY(hero.getTranslateY()+5);
//        System.out.println(hero.getBoundsInParent().getMaxY());
        if(hero.getBoundsInParent().getMaxY()>=700){
            fall_charactertimeline.stop();
            GamePlayController.go_to_start();
        }
    }

    //checks if placement is valid
    //1 : overshoot
    //0 : fine placement
    //-1: undershoot
    private static int placement_validity(){
        stickLim = (int)Math.floor(stick.getBoundsInParent().getMaxX());

//        System.out.println("PivotX : " + stickLim);
//        System.out.println("MinX : " + Math.floor(platform2.getBoundsInParent().getMinX()));
        //condition of undershoot
        if(stickLim < Math.floor(platform2.getBoundsInParent().getMinX())){
            return -1;
        }
        else if(stickLim > Math.floor(platform2.getBoundsInParent().getMaxX())){
            return 1;
        }
        return 0;
    }


    public static void background_shift() {
        platform1=GamePlayController.get_platform1().platform;
        platform2=GamePlayController.get_platform2().platform;
        stick=GamePlayController.get_stick().stick;
        hero=GamePlayController.get_hero().hero;
        cherry_image=GamePlayController.get_cherry().cherry_image;
        hero_maxX=Math.floor(hero.getBoundsInParent().getMaxX());

//        System.out.println("Hero MAX: ");
//        System.out.println(hero_maxX);

        //calling overshoot and undershoot conditions here
        if(placement_validity() == 1){
            overShoot = true;
//            System.out.println("0000000000000000000000T_TT_TT_TT_TT_TT_TT_TOverShootT_TT_TT_TT_TT_TT_TT_T0000000000000000000000");
        }
        else if (placement_validity() == -1){
            underShoot = true;
//            System.out.println("0000000000000000000000T_TT_TT_TT_TT_TT_TT_TUnderShootT_TT_TT_TT_TT_TT_TT_T0000000000000000000000");
        }
        else{
            isValidPlacement = true;
//            System.out.println("0000000000000000000000T_TT_TT_TT_TT_TT_TT_TPerfect!T_TT_TT_TT_TT_TT_TT_T0000000000000000000000");
        }
        KeyFrame platform1Frame = new KeyFrame(Duration.millis(10), e ->
        {
            platform1_shift();
        });

        platform1timeline = new Timeline(platform1Frame);
        platform1timeline.setCycleCount(Timeline.INDEFINITE);

        KeyFrame platform2Frame = new KeyFrame(Duration.millis(10), e ->
        {
            platform2_shift();
        });

        platform2timeline = new Timeline(platform2Frame);
        platform2timeline.setCycleCount(Timeline.INDEFINITE);

        KeyFrame stick_shiftFrame = new KeyFrame(Duration.millis(10), e ->
        {
            try {
                stick_shift();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        });

        stick_shifttimeline = new Timeline(stick_shiftFrame);
        stick_shifttimeline.setCycleCount(Timeline.INDEFINITE);

        KeyFrame new_platformFrame = new KeyFrame(Duration.millis(10), e ->
        {
            emerge_newplatform();
        });

        new_platformtimeline = new Timeline(new_platformFrame);
        new_platformtimeline.setCycleCount(Timeline.INDEFINITE);

        KeyFrame cherryFrame = new KeyFrame(Duration.millis(10), e ->
        {
            cherry_shift();
        });

        cherrytimeline = new Timeline(cherryFrame);
        cherrytimeline.setCycleCount(Timeline.INDEFINITE);

        KeyFrame new_stickFrame = new KeyFrame(Duration.millis(10), e ->
        {
            bringing_stick();
        });

        new_sticktimeline = new Timeline(new_stickFrame);
        new_sticktimeline.setCycleCount(Timeline.INDEFINITE);

        KeyFrame fall_characterFrame = new KeyFrame(Duration.millis(10), e ->
        {
            try {
                falling_character();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        });

        fall_charactertimeline = new Timeline(fall_characterFrame);
        fall_charactertimeline.setCycleCount(Timeline.INDEFINITE);

        KeyFrame rotate_stickFrame = new KeyFrame(Duration.millis(10), e ->
        {
            try {
                rotate_stick();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        });

        rotate_sticktimeline= new Timeline(rotate_stickFrame);
        rotate_sticktimeline.setCycleCount(Timeline.INDEFINITE);

        platform1timeline.play();
        platform2timeline.play();
        stick_shifttimeline.play();
        cherrytimeline.play();

    }
}