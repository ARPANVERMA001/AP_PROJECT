package stickhero.stickhero;

import javafx.scene.image.ImageView;

public class Platform {
    public ImageView platform;
    Platform(ImageView platform){
        this.platform=platform;
    }
}