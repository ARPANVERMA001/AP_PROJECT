package stickhero.stickhero;

import java.io.Serializable;

public class Save implements Serializable{
    private int lives;
    private int cherries;
    private int score;
    Save(int lives, int cherries, int score){
        this.lives = lives;
        this.cherries = cherries;
        this.score = score;
    }

    public int getLives() {
        return lives;
    }

    public int getCherries() {
        return cherries;
    }

    public int getScore() {
        return score;
    }
}
