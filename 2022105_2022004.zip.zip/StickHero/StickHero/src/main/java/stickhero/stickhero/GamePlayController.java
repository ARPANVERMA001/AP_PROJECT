package stickhero.stickhero;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.junit.Test;

import java.io.*;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

import static java.lang.Thread.sleep;

public class GamePlayController implements Initializable {

    public static int background_move=0;//Zero when the background is clickable and active for increasing the stick length and angle of the stick!
    public static int score=0;
    public static int inverse_flag=0;
    public static int cherry_bonus=0;
    public static int lives=0;
    public static int obstructing_flip=0;
//    public static double timer=0;   //time the game has been played for; in seconds
    private int clicked=0;

    @FXML
    private Label cherry_label;

    @FXML
    private Label score_label;

    @FXML
    private Label  lives_label;

    @FXML
    private Label timer_label;

    @FXML
    private ImageView cherry;

    @FXML
    private ImageView hero;

    @FXML
    private  Rectangle stick;

    @FXML
    private  ImageView platform1;

    @FXML
    private  ImageView platform2;

    @FXML
    private ImageView save_icon;

    @FXML
    private ImageView timer_icon;

    @FXML
    private ImageView lives_icon;

    @FXML
    private ImageView cherries_icon;

    @FXML
    private ImageView gameOverText;

    @FXML
    private ImageView respawnText;

    @FXML
    private ImageView yes_button;

    @FXML
    private ImageView no_button;

    @FXML
    void save_progress(MouseEvent event) throws IOException {
        serialize();
    }

    private Background background;
    private Icon timer_icon_;

    private static Stick sticks;
    private static Platform platform_1;
    private static Platform platform_2;
    private static Hero hero_;
    private static Cherry cherry_;
    private static Labels cherry_label_;
    private static Labels score_label_;
    private static Labels lives_label_;
    private static Labels timer_label_;

    private static Save savedProgress;
    private static boolean hasBeenDesrialized;
    private static ImageResource gameOverTextImage;
    private static ImageResource respawntextImage;
    private static ImageResource yesButtonImage;
    private static ImageResource noButtonImage;

    public static TimerThread timerThread;
    public static TesterThread testerThread;

    public static TimerThread get_timer(){return timerThread;}
    public static TesterThread get_tester(){return testerThread;}
    public static ImageResource get_yes_button(){
        return yesButtonImage;
    }
    public static ImageResource get_no_button(){
        return noButtonImage;
    }

    public static int get_cherry_bonus(){
        return cherry_bonus;
    }
    public static int get_score(){
        return score;

    }
    public static int get_lives(){
        return lives;
    }
    public static Platform get_platform1(){
        return platform_1;
    }

    public static Platform get_platform2(){
        return platform_2;
    }

    public static Labels get_score_label(){
        return score_label_;
    }

    public static Labels get_timer_label(){return timer_label_;}

    public static Stick get_stick(){
        return sticks;
//        return null;
    }
    public static double get_hero_max(){
        return hero_.hero.getBoundsInParent().getMaxX();
    }

    public static void update_lives(){
        lives = (int)(cherry_bonus/3);
    }
    public static double get_stick_initialX(){
//        System.out.println("InitialX:");
//        System.out.println(sticks.initialX);
        return sticks.initialX;
    }
    public static double get_stick_initialY(){
//        System.out.println("InitialY:");
//        System.out.println(sticks.initialY);
        return sticks.initialY;
    }
    public static double get_stick_initial_height(){
//        System.out.println("InitialHeight:");
//        System.out.println(sticks.height);
        return sticks.height;
    }
    public static Hero get_hero(){
        return hero_;
    }
    public static Cherry get_cherry(){
        return cherry_;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
//        System.out.println("initializing");
        if(background_move == 1){
//            System.out.println("back_move = 1");
            background_move = 0;
//            System.out.println("back_move = 0");
            update_lives();
            if(!hasBeenDesrialized) {
                lives = lives - 1;
            }

//            System.out.println("lives = lives -1");
//            lives_label_ = new Labels(lives_label);
        }
        timer_icon_=Icon.getInstance(timer_icon);

        sticks = new Stick(stick);
        platform_1=new Platform(platform1);
        platform_2=new Platform(platform2);
//        hero_=Hero.getInstance(hero);
        hero_=new Hero(hero);
        cherry_=new Cherry(cherry);
        cherry_label_= new Labels(cherry_label);
//        cherry_label_.label.setText(": " + cherry_bonus);
        score_label_= new Labels(score_label);
//        score_label_.label.setText(": " + score);
        timer_label_ = new Labels(timer_label);
        gameOverTextImage = new ImageResource(gameOverText);
        respawntextImage = new ImageResource(respawnText);
        yesButtonImage = new ImageResource(yes_button);
        noButtonImage = new ImageResource(no_button);
        lives_label_ = new Labels(lives_label);
        lives_label_.label.setText(": " + lives);
        //Start a Thread which stores the time the game has been played for
        timerThread=new TimerThread();
        timerThread.start();
        testerThread=new TesterThread();
        testerThread.start();

//        System.out.println("Back_move" + background_move);
//        System.out.println("Score: " + score);
//        System.out.println("inv_flag:"  + inverse_flag);
//        System.out.println("obst_flag: " + obstructing_flip);
    }

    @FXML
    private void background_start() {
        if(background_move==0) {
            if (clicked == 0) {
//                System.out.println("inside click==0");
                OutfitHero new_outfit_hero= new OutfitHero(hero_);
                new_outfit_hero.change_character_outfit();
//                System.out.println(sticks.counter);
                sticks.callme();
                clicked++;
            } else {
//                System.out.println("inside click!=0");
                sticks.stopthegame();
                sticks.startrotate();
                clicked = 0;
            }
        }
        else{
//            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!8769857957657!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
//            System.out.println(hero.getBoundsInParent().getMaxX());
//            System.out.println(platform1.getBoundsInParent().getMaxX());

            if(hero.getBoundsInParent().getMaxX()<= platform1.getBoundsInParent().getMaxX()){
//                System.out.println("Do not flip!!!");
            }
            else if(obstructing_flip==0){
                Hero.flip_hero(hero_);
            }
        }
    }

    public static void checkCollision() {
        if(isColliding(hero_, cherry_) && (Background.overShoot || Background.underShoot)){
            cherry_.cherry_image.setOpacity(0);
        }
        if (isColliding(hero_, cherry_) && !Background.overShoot && !Background.underShoot) {
            cherry_bonus++;
            update_lives();
            cherry_label_.label.setText(": "+cherry_bonus);
            cherry_.cherry_image.setOpacity(0);

            lives_label_.label.setText(": " + lives);
            // Optionally, you may want to reset the cherry's position or do other actions
//            Cherry.resetCherryPosition(cherry_);
        }
    }

    public static boolean isColliding(Hero hero, Cherry cherry) {
        return hero.hero.getBoundsInParent().intersects(cherry.cherry_image.getBoundsInParent());
    }

    public ImageView get_save_icon() {
        return save_icon;
    }

    public static ImageResource get_game_over_text() {
        return gameOverTextImage;
    }

    public static ImageResource get_respawn_text() {
        return respawntextImage;
    }

    public void respawn_decision_yes(MouseEvent mouseEvent) throws IOException {
        if(yes_button.getOpacity()!=0) {
//            System.out.println("Respawn decision YES!!!");
            Stage stage = Main.get_stage();

            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("GamePlay.fxml")));
            Scene scene = new Scene(root, 800, 600);
            stage.setTitle("StickHero!");
            stage.setScene(scene);
//
//            background_move = 0;
            Background.underShoot = false;
            Background.overShoot = false;
            Background.check_cherry = 0;
            Background.cherry_current_updown = 1;
            lives = lives - 1;
            Background.stop_all = 0;
            Background.get_fall_timeline().stop();
            stage.show();
        }
    }

    public static void serialize() throws IOException{
        Save progressSave = new Save(lives, cherry_bonus, score);
        ObjectOutputStream out = null;
        try{
            out = new ObjectOutputStream(new FileOutputStream("D:\\Codes\\StickHero\\StickHero\\src\\main\\resources\\stickhero\\stickhero\\Scores\\Save.txt"));
            out.writeObject(progressSave);
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
        finally{
            if(out != null){
                out.close();
            }
        }
    }

    public static void deserialize() throws IOException{
        ObjectInputStream in = null;
        try{
            in = new ObjectInputStream(new FileInputStream("D:\\Codes\\StickHero\\StickHero\\src\\main\\resources\\stickhero\\stickhero\\Scores\\Save.txt"));
            savedProgress = (Save) in.readObject();
            System.out.println("Deserialized lives : " + savedProgress.getLives() + " cherries: " + savedProgress.getCherries() + " score: " + savedProgress.getScore());
//            load_game();
            hasBeenDesrialized = true;
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        catch (IOException e){
            e.getMessage();
        }
        finally{
            if(in != null){
                in.close();
            }

        }
    }

    public static Save load_game() throws IOException {
        return savedProgress;
    }

    public void respawn_decision_no(MouseEvent mouseEvent) throws IOException {
        if (noButtonImage.image.getOpacity() != 0) {
//            System.out.println("Respawn decision No!!!!");

            serialize();

            Stage stage = Main.get_stage();

            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("StartMenu.fxml")));
            Scene scene = new Scene(root, 800, 600);
            stage.setTitle("StickHero!");
            stage.setScene(scene);
//
//            background_move = 0;
            Background.underShoot = false;
            Background.overShoot = false;
            Background.check_cherry = 0;
                Background.cherry_current_updown = 1;
////                Background.flag_rotate_count = 0;
                lives = 0;
                cherry_bonus = 0;
                score = 0;
////                obstructing_flip=0;
            Background.stop_all = 0;
            Background.get_fall_timeline().stop();
            stage.show();
            }
//        }
    }

    public static void call_respawn_from_game_over() throws IOException, InterruptedException {
        go_to_start();
    }
    public static void go_to_start() throws IOException, InterruptedException {
//        System.out.println("Respawn decision No!!!!");
    Stage stage = Main.get_stage();
        sleep(1000);
        Parent root = FXMLLoader.load(Objects.requireNonNull(GamePlayController.class.getResource("StartMenu.fxml")));
        Scene scene = new Scene(root, 800, 600);
        stage.setTitle("StickHero!");
        stage.setScene(scene);
//
//            background_move = 0;
        Background.underShoot = false;
        Background.overShoot = false;
        Background.check_cherry = 0;
        Background.cherry_current_updown = 1;
////                Background.flag_rotate_count = 0;
        lives = 0;
        cherry_bonus = 0;
        score = 0;
////                obstructing_flip=0;
        Background.stop_all = 0;
        Background.get_fall_timeline().stop();
        stage.show();
    }

}