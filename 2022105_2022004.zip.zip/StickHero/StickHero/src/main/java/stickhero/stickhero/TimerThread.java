package stickhero.stickhero;
import javafx.application.Platform;

public class TimerThread extends Thread{
    private double timer;
    private boolean running;

    TimerThread(){
        this.timer=0.0; this.running=true;
    }

    public void stop_timer(){
        running = false;
    }
    public void start_timer(){
        running=true;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000); // Sleep for 1 second (1000 milliseconds)
                if(running) {
                    timer += 1.0; // Increment the timer by 1 second
                    Platform.runLater(() -> {
                        GamePlayController.get_timer_label().label.setText(": " + timer);
                    });
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}