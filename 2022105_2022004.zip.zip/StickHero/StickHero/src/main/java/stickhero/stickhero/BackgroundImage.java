package stickhero.stickhero;

import javafx.scene.image.ImageView;

public class BackgroundImage {
    public ImageView background_image;
    BackgroundImage(ImageView background_image){
        this.background_image=background_image;
    }
}