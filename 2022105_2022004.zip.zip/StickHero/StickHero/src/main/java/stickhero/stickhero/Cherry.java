package stickhero.stickhero;

import javafx.scene.image.ImageView;

public class Cherry {
    public ImageView cherry_image;
    Cherry(ImageView cherry_image){
        this.cherry_image=cherry_image;
    }


}