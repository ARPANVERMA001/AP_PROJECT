package stickhero.stickhero;

import javafx.scene.control.Label;

public class Labels {
    public Label label;
    Labels(Label label){
        this.label=label;
    }
}