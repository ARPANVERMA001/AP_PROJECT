package stickhero.stickhero;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class GamePlayController implements Initializable {

    public static int background_move=0;//Zero when the background is clickable and active for increasing the stick length and angle of the stick!

    @FXML
    private Rectangle stick;

    private Stick sticks;
    private int clicked=0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
//        System.out.println("\n\n\n\n\n\naloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo\n\n\n");
//        System.out.println(stick.getHeight());
        sticks = new Stick(stick);
//        System.out.println(stick.getHeight());
    }

    @FXML
    private void background_start() {
        if(background_move==0) {
            if (clicked == 0) {
                System.out.println(sticks.counter);
                sticks.callme();
                clicked++;
            } else {
                sticks.stopthegame();
                sticks.startrotate();
                clicked = 0;
            }
        }
        else{
            System.out.println("We haven't updated background_start hence wont use the function");
        }
    }
}