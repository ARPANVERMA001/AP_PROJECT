package stickhero.stickhero;

public interface Runner {
    public void run();
}
