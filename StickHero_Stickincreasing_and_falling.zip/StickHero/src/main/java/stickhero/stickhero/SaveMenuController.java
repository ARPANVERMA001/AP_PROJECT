package stickhero.stickhero;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;

public class SaveMenuController {
    //Buttons
    public Button Save1;
    public Button Save2;
    public Button Save3;
    public Button Save4;
    public Button Save5;
    public Button Save6;

    public void goToSave1(ActionEvent event){
        System.out.println("Going to save 1");
    }
    public void goToSave2(ActionEvent event){
        System.out.println("Going to save 2");
    }
    public void goToSave3(ActionEvent event){
        System.out.println("Going to save 3");
    }
    public void goToSave4(ActionEvent event){
        System.out.println("Going to save 4");
    }
    public void goToSave5(ActionEvent event){
        System.out.println("Going to save 5");
    }
    public void goToSave6(ActionEvent event){
        System.out.println("Going to save 6");
    }

//    public GamePlay()
}
