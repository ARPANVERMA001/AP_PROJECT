package stickhero.stickhero;

public interface Collectable {
    public void spawn();
    public void despawn();
}
