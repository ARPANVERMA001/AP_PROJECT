package stickhero.stickhero;

public class Character implements Runner{

    public void run(){
        //code here
    }
}
