package com.example.ap_proj;

public interface EnvironmentVariable {
    public void draw();
}
