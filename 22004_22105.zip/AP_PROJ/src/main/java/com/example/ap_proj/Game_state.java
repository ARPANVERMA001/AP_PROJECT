package com.example.ap_proj;

public class Game_state {
    public void start(){

    }
    public void end(){

    }
}
