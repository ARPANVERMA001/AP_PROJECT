package com.example.ap_proj;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

public class LoginPage {

    @FXML
    void Exit(MouseEvent event) {

    }

    @FXML
    void Info(MouseEvent event) {

    }

    @FXML
    void Login(MouseEvent event) {

    }

}