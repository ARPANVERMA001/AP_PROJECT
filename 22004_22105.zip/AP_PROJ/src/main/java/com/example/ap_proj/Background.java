package com.example.ap_proj;

import javafx.scene.image.Image;

import java.util.Random;

public class Background{
    private Image backgroundImage;

    //MOVES the Background
    public void move_background(){//Do this when the character is running

    }
    //
    public void draw(){ //Randomly generates buildings!

    }

}