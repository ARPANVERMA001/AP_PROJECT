package com.example.ap_proj;

public interface Runner {
    public void run();
    public void stop();
    public void fall();
}
