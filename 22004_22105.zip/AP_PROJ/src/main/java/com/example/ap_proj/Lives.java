package com.example.ap_proj;

public class Lives {
    int lives;
    public void decrease_lives(){//Reduce lives of the player on wrong moves

    }
    public void points_to_lives(){//Increases Lives by deducting a few points, will call decrement_points of class Points

    }
}