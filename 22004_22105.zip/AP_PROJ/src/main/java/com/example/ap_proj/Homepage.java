package com.example.ap_proj;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

public class Homepage {

    @FXML
    void back(MouseEvent event) {

    }

    @FXML
    void saved_game(MouseEvent event) {

    }

    @FXML
    void start(MouseEvent event) {

    }

}
