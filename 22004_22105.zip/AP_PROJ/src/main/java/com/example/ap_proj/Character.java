package com.example.ap_proj;

import javafx.scene.image.Image;

public class Character implements Runner{

    private int xPos;
    private int yPos;
    private int CHAR_WIDTH;
    private int CHAR_HEIGHT;
    private Image charImage;

    public void invert(){ //When the character is running on the press of a spacebar, the character would get inverted

    }
    public void draw(){

    }
    public void run(){

    }
    public void stop(){

    }
    public void fall(){     //Make the character fall when the stick falls

    }
}