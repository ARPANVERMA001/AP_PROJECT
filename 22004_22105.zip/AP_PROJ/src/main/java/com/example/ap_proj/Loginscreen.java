package com.example.ap_proj;

import javafx.fxml.FXML;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.MouseEvent;

public class Loginscreen {

    @FXML
    void back(MouseEvent event) {

    }

    @FXML
    void login_input(InputMethodEvent event) {

    }

    @FXML
    void password_input(InputMethodEvent event) {

    }

    @FXML
    void register(MouseEvent event) {

    }

}