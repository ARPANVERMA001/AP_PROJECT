package com.example.ap_proj;

public class Points {
    private int score;
    public void draw(){

    }
    public void increase_points(){

    }
    public void decrease_points(){

    }
}