package com.example.ap_proj;

public class Cherry implements Collectable{

    private int xPos;
    private int yPos;
    private int CHERRY_WIDTH;
    private int CHERRY_HEIGHT;

    public void spawn(){

    }
    public void cherry_bonus(){ //Adds the bonus of the cherry to the overall points

    }
    public void disappear_cherry(){ //As the character touches the cherry, it disappears

    }
}