package com.example.ap_proj;

public interface Collectable {
    public void spawn();
}
