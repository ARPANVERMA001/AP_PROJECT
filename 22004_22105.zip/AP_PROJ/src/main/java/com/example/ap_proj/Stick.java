package com.example.ap_proj;

public class Stick implements EnvironmentVariable{
    private int xPos;
    private int yPos;
    private int STICK_WIDTH;
    private int STICK_HEIGHT;

    public void draw(){

    }
    public void start_growing(){

    }
    public void stop_growing(){

    }

    //TRANSFORMATION
    public void start_rotate(){

    }
    public void stop_rotate(){

    }
    public void reinitialise(){ //After 1 level the stick comes to the original position with the original length

    }
    public void fall(){  //Make it fall if it extends the block!

    }
}